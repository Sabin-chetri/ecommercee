<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Your Cart</title>
    <link rel="stylesheet" href=<?php echo e(url('assets/css/app.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(url('assets/css/cart.css')); ?>>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    </head>
    <body> 
        <hr>
    <h1 class="heading">Your Cart List is Here</h1>
    <hr>
    <!-- Button trigger modal -->
<button type="button" class="btn btn-primary placeorder" data-bs-toggle="modal" data-bs-target="#exampleModal">
    Place Order
  </button>
  
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Confirm Order</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display: flex;gap:20px;align-items:center;justify-content:space-between;">
                <img style="width: 50px;height: 50px; margin-bottom:5px;" src="<?php echo e(url('upload')); ?>/<?php echo e($product->productImage); ?>" alt="">
                
                <h4 style=""><?php echo e($product->productName); ?></h4>

                <h6>Rs. <span id="abcd"><?php echo e($product->productPrice); ?></span></h6>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
<hr>
            <div style="display: flex;justify-content:flex-end;">
                <h5>Total Price: Rs.</h5>
                <h5 id="total-price"></h5>
            </div>
        
        <script>
            // JavaScript to calculate total price
            document.addEventListener("DOMContentLoaded", function() {
                var prices = document.querySelectorAll("#abcd");
                var totalPrice = 0;
        
                for (var i = 0; i < prices.length; i++) {
                    totalPrice += parseFloat(prices[i].textContent);
                }
        
                document.getElementById("total-price").textContent = totalPrice.toFixed(2);
            });
        </script>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Confirm</button>
        </div>
      </div>
    </div>
  </div>




    <div class="cartList">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cartItem">
            <div class="cartImage">
                <img src="<?php echo e(url('upload')); ?>/<?php echo e($product->productImage); ?>" alt="">
            </div>
            <div class="cartName">
                <h4><?php echo e($product->productName); ?></h4>
            </div>
            <div class="cartPrice">
                <h4 id="abc">Rs. <?php echo e($product->productPrice); ?></h4>
                
            </div>
            <div class="cartQuantity">
            <input class="quantity" onchange="changed();"type="number" name="user" id="user" value=1 min="1">
            </div>
            <div class="cartTotalPrice">
                <h4 id="fin">
                <?php
                    $user = 5;
                    $final = $product->productPrice*$user;
                    echo "$final"
                ?>
                
                </h4>
            </div>
            <div>
                <a href="<?php echo e(url('cartDelete')); ?>/<?php echo e($product->id); ?>"><i class="fa-solid fa-trash delete"></i></a>
            </div>
        </div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\latestxampp\htdocs\laravel-app\finalllProject\example-app\resources\views/cart.blade.php ENDPATH**/ ?>