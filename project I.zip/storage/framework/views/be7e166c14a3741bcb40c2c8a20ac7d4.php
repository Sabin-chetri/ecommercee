
<img src="<?php echo e(url('assets/image/logo.png')); ?>" alt="loading">
<?php /**PATH C:\latestxampp\htdocs\laravel-app\finalllProject\example-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>