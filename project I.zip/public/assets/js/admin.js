// let tabContainer = document.querySelector(".tabContainer");
//         let tabContent = document.querySelector(".tabContent > div");
//         tabContent.forEach((content,index) => {
//             if(index!==0)
//             content.setAttrubute('hidden','true');
//         });
//         tabContainer.addEventListener('click',(e)=>{
//             const clickedTab = e.target.closest('a');
//             if(!clickedTab) return;
//             e.preventDefault();
//             const clickedLink = clickedTab.getAttribute('href');
//             tabContent.forEach((content,index) => {
//             if(index!==0)
//             content.setAttrubute('hidden','true');
//         });
//         document.querySelector(clickedLink).removeAttribute('hidden');
//         });
console.console.log('ea');